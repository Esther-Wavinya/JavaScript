let dishesToDo = [ 'large platter' ];

//to add to the start:
dishesToDo.unshift('plate');

//add to the start again:
dishesToDo.unshift('cereal bowl');
dishesToDo.unshift('spoon');

//remove from the start:
dishesToDo.shift();
